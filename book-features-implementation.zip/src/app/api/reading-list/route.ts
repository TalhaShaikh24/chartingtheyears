import { connectDB } from '@/lib/db';
import ReadingListModel from '@/models/ReadingList';
import BookModel from '@/models/Book';
import { NextRequest, NextResponse } from 'next/server';

// GET - Fetch user's reading list
export async function GET(request: NextRequest) {
  try {
    await connectDB();

    const userId = request.nextUrl.searchParams.get('userId');
    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const readingList = await ReadingListModel.findOne({ userId });
    if (!readingList) {
      return NextResponse.json({ data: { bookIds: [] } }, { status: 200 });
    }

    // Fetch full book details for each book ID
    const books = await BookModel.find({ _id: { $in: readingList.bookIds } });

    return NextResponse.json(
      { data: books },
      { status: 200 }
    );
  } catch (error) {
    console.error('[v0] Reading list GET error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reading list' },
      { status: 500 }
    );
  }
}

// POST - Add book to reading list
export async function POST(request: NextRequest) {
  try {
    await connectDB();

    const body = await request.json();
    const { userId, bookId } = body;

    if (!userId || !bookId) {
      return NextResponse.json(
        { error: 'User ID and Book ID are required' },
        { status: 400 }
      );
    }

    // Verify book exists
    const book = await BookModel.findById(bookId);
    if (!book) {
      return NextResponse.json(
        { error: 'Book not found' },
        { status: 404 }
      );
    }

    let readingList = await ReadingListModel.findOne({ userId });

    if (!readingList) {
      readingList = new ReadingListModel({
        userId,
        bookIds: [bookId],
      });
    } else {
      if (!readingList.bookIds.includes(bookId)) {
        readingList.bookIds.push(bookId);
      }
    }

    await readingList.save();

    return NextResponse.json(
      { data: readingList, message: 'Book added to reading list' },
      { status: 200 }
    );
  } catch (error) {
    console.error('[v0] Reading list POST error:', error);
    return NextResponse.json(
      { error: 'Failed to add book to reading list' },
      { status: 500 }
    );
  }
}

// DELETE - Remove book from reading list
export async function DELETE(request: NextRequest) {
  try {
    await connectDB();

    const body = await request.json();
    const { userId, bookId } = body;

    if (!userId || !bookId) {
      return NextResponse.json(
        { error: 'User ID and Book ID are required' },
        { status: 400 }
      );
    }

    const readingList = await ReadingListModel.findOne({ userId });
    if (!readingList) {
      return NextResponse.json(
        { error: 'Reading list not found' },
        { status: 404 }
      );
    }

    readingList.bookIds = readingList.bookIds.filter(
      (id: string) => id !== bookId
    );
    await readingList.save();

    return NextResponse.json(
      { data: readingList, message: 'Book removed from reading list' },
      { status: 200 }
    );
  } catch (error) {
    console.error('[v0] Reading list DELETE error:', error);
    return NextResponse.json(
      { error: 'Failed to remove book from reading list' },
      { status: 500 }
    );
  }
}
