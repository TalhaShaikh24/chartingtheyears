import { connectDB } from '@/lib/db';
import ReviewModel from '@/models/Review';
import BookModel from '@/models/Book';
import { NextRequest, NextResponse } from 'next/server';

// GET - Fetch reviews for a book
export async function GET(request: NextRequest) {
  try {
    await connectDB();

    const bookId = request.nextUrl.searchParams.get('bookId');
    if (!bookId) {
      return NextResponse.json(
        { error: 'Book ID is required' },
        { status: 400 }
      );
    }

    const reviews = await ReviewModel.find({ bookId }).sort({ createdAt: -1 });

    return NextResponse.json(
      { data: reviews },
      { status: 200 }
    );
  } catch (error) {
    console.error('[v0] Reviews GET error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch reviews' },
      { status: 500 }
    );
  }
}

// POST - Create a review
export async function POST(request: NextRequest) {
  try {
    await connectDB();

    const body = await request.json();
    const { bookId, userName, rating, comment } = body;

    if (!bookId || !rating) {
      return NextResponse.json(
        { error: 'Book ID and rating are required' },
        { status: 400 }
      );
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json(
        { error: 'Rating must be between 1 and 5' },
        { status: 400 }
      );
    }

    // Verify book exists
    const book = await BookModel.findById(bookId);
    if (!book) {
      return NextResponse.json(
        { error: 'Book not found' },
        { status: 404 }
      );
    }

    const review = new ReviewModel({
      bookId,
      userName: userName || 'Anonymous',
      rating,
      comment: comment || '',
    });

    await review.save();

    return NextResponse.json(
      { data: review, message: 'Review created successfully' },
      { status: 201 }
    );
  } catch (error) {
    console.error('[v0] Reviews POST error:', error);
    return NextResponse.json(
      { error: 'Failed to create review' },
      { status: 500 }
    );
  }
}
