'use client';

import { useState, useEffect } from 'react';
import { ReadingListCard } from '@/components/features/ReadingListCard';
import apiClient from '@/lib/apiClient';
import { useRouter } from 'next/navigation';

interface Book {
  _id: string;
  title: string;
  author: string;
  category: string;
  language: string;
  rating: number;
  imageUrl?: string;
}

export default function ReadingListPage() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  // Generate a consistent user ID for demo (in production, use actual auth)
  const getUserId = () => {
    if (typeof window === 'undefined') return 'default-user';
    const stored = localStorage.getItem('demo-user-id');
    if (stored) return stored;
    const newId = `user-${Date.now()}`;
    localStorage.setItem('demo-user-id', newId);
    return newId;
  };

  useEffect(() => {
    const fetchReadingList = async () => {
      try {
        setLoading(true);
        setError(null);
        const userId = getUserId();
        const response = await apiClient.get<{ data: Book[] }>(
          `/api/reading-list?userId=${userId}`
        );
        setBooks(response.data.data || []);
      } catch (err) {
        console.error('[v0] Failed to fetch reading list:', err);
        setError('Failed to load reading list');
      } finally {
        setLoading(false);
      }
    };

    fetchReadingList();
  }, []);

  const handleRemoveBook = async (bookId: string) => {
    try {
      const userId = getUserId();
      await apiClient.delete('/api/reading-list', {
        data: { userId, bookId },
      });
      setBooks((prev) => prev.filter((b) => b._id !== bookId));
    } catch (err) {
      console.error('[v0] Failed to remove book:', err);
      setError('Failed to remove book from reading list');
    }
  };

  return (
    <div className="min-h-screen bg-canvas p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-ink mb-2">Reading List</h1>
          <p className="text-ink-mute">
            {books.length === 0
              ? 'Start adding books to build your reading list'
              : `You have ${books.length} book${books.length !== 1 ? 's' : ''} in your reading list`}
          </p>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 rounded-lg bg-danger/10 border border-danger/30 text-danger">
            {error}
          </div>
        )}

        {/* Loading State */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="rounded-xl bg-surface border border-line/60 animate-pulse">
                <div className="w-full aspect-[3/4] bg-surface-2" />
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-surface-2 rounded w-3/4" />
                  <div className="h-3 bg-surface-2 rounded w-1/2" />
                  <div className="h-8 bg-surface-2 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : books.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {books.map((book) => (
              <ReadingListCard
                key={book._id}
                {...book}
                onRemove={handleRemoveBook}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="mb-4 text-5xl">📚</div>
            <h2 className="text-2xl font-semibold text-ink mb-2">
              Your reading list is empty
            </h2>
            <p className="text-ink-mute mb-6">
              Explore books from the Atlas and add them to your reading list
            </p>
            <button
              onClick={() => router.push('/user')}
              className="inline-flex items-center justify-center gap-2 h-10 px-4 text-sm font-medium rounded-lg bg-ink text-canvas hover:bg-ink-soft transition-colors"
            >
              Explore Books
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
