import React from 'react';

export default function AboutPage() {
  const features = [
    {
      icon: '☰',
      title: 'World atlas',
      description: 'Browse books by geography — click any country on the interactive map to see all books tagged to that location.',
    },
    {
      icon: '🕐',
      title: 'Timeline filter',
      description: 'Travel across six historical eras from Ancient to Post-war and see which books belong to each period.',
    },
    {
      icon: '⚖️',
      title: 'Deep filtering',
      description: 'Narrow your search by language, type, star rating, publication year, and a full library of subject tags.',
    },
    {
      icon: '⭐',
      title: 'Rated reviews',
      description: 'Every book is rated 1–5 stars with a full written review covering scholarly merit and narrative quality.',
    },
    {
      icon: '☑️',
      title: 'Reading list',
      description: 'Save any book to your personal reading list and track your average rating across your saved collection.',
    },
    {
      icon: '⚙️',
      title: 'Admin panel',
      description: 'Add, edit, and manage books, categories, and tags through the built-in admin dashboard — no coding needed.',
    },
  ];

  return (
    <div className="min-h-screen bg-canvas">
      {/* Header */}
      <div className="max-w-6xl mx-auto px-6 py-16">
        <h1 className="text-5xl font-bold text-ink mb-6">About</h1>

        {/* Introduction */}
        <div className="space-y-6 mb-16">
          <p className="text-lg text-ink leading-relaxed">
            HistoryBookMap is a new way to explore the world through books. Browse hundreds of reviews organised by
            geography, time period, and subject matter on an interactive world atlas.
          </p>
          <p className="text-lg leading-relaxed">
            <span className="text-accent font-medium">
              Click any country on the map to see books tagged to it. Use the era timeline to travel between historical periods.
            </span>
            {' '}Filter by category, language, rating, and subject tags to find exactly what you are looking for.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {features.map((feature, index) => (
            <div
              key={index}
              className="rounded-2xl bg-ink text-canvas p-8 space-y-3 hover:shadow-lg transition-shadow"
            >
              <div className="text-3xl mb-2">{feature.icon}</div>
              <h3 className="text-xl font-semibold">{feature.title}</h3>
              <p className="text-sm leading-relaxed text-canvas/90">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* About the Reviewer Section */}
        <div className="rounded-2xl bg-ink text-canvas p-8 md:p-12">
          <h2 className="text-3xl font-bold mb-4">About the reviewer</h2>
          <p className="text-base leading-relaxed text-canvas/90">
            This site collects reviews written over many years across multiple platforms. The collection spans 300+ books
            covering all periods and regions of world history, with a focus on accessible narrative history for the general reader.
            Reviews are written in English with select titles available in French. New reviews are added regularly as the collection
            continues to grow.
          </p>
        </div>
      </div>
    </div>
  );
}
