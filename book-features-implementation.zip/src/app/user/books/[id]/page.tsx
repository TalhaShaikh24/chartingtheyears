'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Stars } from '@/components/ui/kit/Stars';
import { KitButton } from '@/components/ui/kit/Button';
import { BookReviewForm } from '@/components/features/BookReviewForm';
import { BookReviewSection } from '@/components/features/BookReviewSection';
import apiClient from '@/lib/apiClient';

interface Book {
  _id: string;
  title: string;
  author: string;
  category: string;
  language: string;
  type: string;
  rating: number;
  historicalYear: number;
  publicationYear: number;
  reviewText?: string;
  imageUrl?: string;
  country?: string;
  tags?: string[];
}

export default function SingleBookPage() {
  const params = useParams();
  const router = useRouter();
  const bookId = params.id as string;

  const [book, setBook] = useState<Book | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviewRefresh, setReviewRefresh] = useState(0);
  const [isAddingToList, setIsAddingToList] = useState(false);

  useEffect(() => {
    const fetchBook = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await apiClient.get<{ data: Book }>(
          `/api/books/${bookId}`
        );
        setBook(response.data.data);
      } catch (err) {
        console.error('[v0] Failed to fetch book:', err);
        setError('Failed to load book details');
      } finally {
        setLoading(false);
      }
    };

    if (bookId) {
      fetchBook();
    }
  }, [bookId]);

  const handleAddToReadingList = async () => {
    if (!book) return;

    try {
      setIsAddingToList(true);

      let userId = localStorage.getItem('demo-user-id');
      if (!userId) {
        userId = `user-${Date.now()}`;
        localStorage.setItem('demo-user-id', userId);
      }

      await apiClient.post('/api/reading-list', {
        userId,
        bookId: book._id,
      });

      alert('Book added to your reading list!');
    } catch (error) {
      console.error('[v0] Failed to add to reading list:', error);
      alert('Failed to add book to reading list');
    } finally {
      setIsAddingToList(false);
    }
  };

  const handleReviewSubmitted = () => {
    setReviewRefresh((prev) => prev + 1);
  };

  const placeholderImage = book
    ? `https://placehold.co/300x420/EADCCB/453C38?text=${encodeURIComponent(book.title)}`
    : '';

  if (loading) {
    return (
      <div className="min-h-screen bg-canvas p-6">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-surface-2 rounded w-1/2 mb-8" />
            <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-12">
              <div className="aspect-[3/4] bg-surface-2 rounded-lg" />
              <div className="space-y-4">
                <div className="h-6 bg-surface-2 rounded w-3/4" />
                <div className="h-4 bg-surface-2 rounded w-1/2" />
                <div className="h-20 bg-surface-2 rounded" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !book) {
    return (
      <div className="min-h-screen bg-canvas p-6">
        <div className="max-w-6xl mx-auto text-center py-16">
          <h1 className="text-2xl font-bold text-ink mb-4">Book Not Found</h1>
          <p className="text-ink-mute mb-6">{error || 'The book you are looking for does not exist.'}</p>
          <KitButton onClick={() => router.push('/user')} variant="primary">
            Back to Books
          </KitButton>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-canvas p-6">
      <div className="max-w-6xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => router.back()}
          className="mb-8 inline-flex items-center gap-2 text-ink hover:text-ink-soft transition-colors"
        >
          <span>←</span> Back
        </button>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-12 mb-16">
          {/* Left: Book Cover */}
          <div className="flex flex-col gap-6">
            <div className="relative w-full aspect-[3/4] rounded-xl overflow-hidden bg-surface border border-line/60 flex-shrink-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={book.imageUrl || placeholderImage}
                alt={book.title}
                className="w-full h-full object-cover"
              />
            </div>
            <KitButton
              variant="outline"
              onClick={handleAddToReadingList}
              disabled={isAddingToList}
              className="w-full"
            >
              {isAddingToList ? 'Adding...' : 'Add to Reading List'}
            </KitButton>
          </div>

          {/* Right: Book Details */}
          <div className="space-y-8">
            {/* Title & Author */}
            <div>
              <h1 className="text-4xl font-bold text-ink mb-2">{book.title}</h1>
              <p className="text-xl text-ink-mute">{book.author}</p>
            </div>

            {/* Badges */}
            <div className="flex flex-wrap gap-2">
              {book.country && (
                <span className="px-3 py-1.5 rounded-full text-sm font-semibold bg-ink text-canvas">
                  {book.country}
                </span>
              )}
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold border border-line bg-transparent text-ink">
                {book.category}
              </span>
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold border border-line bg-transparent text-ink">
                {book.language}
              </span>
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold border border-line bg-transparent text-ink">
                {book.type}
              </span>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-3">
              <Stars value={Math.round(book.rating)} size={24} />
              <span className="text-2xl font-bold text-ink">{book.rating.toFixed(1)}/5</span>
            </div>

            {/* Info Boxes */}
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border border-line/60 bg-surface-2 p-6">
                <p className="text-xs uppercase font-semibold text-ink-mute tracking-wider mb-2">
                  Historical Range
                </p>
                <p className="text-2xl font-bold text-ink">{book.historicalYear}</p>
              </div>
              <div className="rounded-lg border border-line/60 bg-surface-2 p-6">
                <p className="text-xs uppercase font-semibold text-ink-mute tracking-wider mb-2">
                  Publication Year
                </p>
                <p className="text-2xl font-bold text-ink">{book.publicationYear}</p>
              </div>
            </div>

            {/* Description */}
            {book.reviewText && (
              <div className="rounded-lg border border-line/60 bg-surface-2 p-6">
                <h3 className="font-semibold text-ink mb-3">Summary</h3>
                <p className="text-sm text-ink leading-relaxed">{book.reviewText}</p>
              </div>
            )}

            {/* Tags */}
            {book.tags && book.tags.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold text-ink">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {book.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1.5 rounded-full text-xs font-medium bg-ink/10 text-ink"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Reviews Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <BookReviewSection bookId={book._id} refreshTrigger={reviewRefresh} />
          </div>
          <div>
            <BookReviewForm bookId={book._id} onReviewSubmitted={handleReviewSubmitted} />
          </div>
        </div>
      </div>
    </div>
  );
}
