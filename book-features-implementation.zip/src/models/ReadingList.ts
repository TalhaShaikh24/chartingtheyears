import mongoose from 'mongoose';

const readingListSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    bookIds: {
      type: [String],
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.models.ReadingList || mongoose.model('ReadingList', readingListSchema);
