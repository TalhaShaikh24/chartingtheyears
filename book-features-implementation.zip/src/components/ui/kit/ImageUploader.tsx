'use client';

import { forwardRef, useRef, useState } from 'react';
import { cn } from '@/lib/utils';

interface ImageUploaderProps {
  onImageChange?: (base64: string) => void;
  initialImage?: string;
  maxSize?: number; // in MB
}

const SUPPORTED_FORMATS = ['image/jpeg', 'image/png', 'image/webp'];
const SUPPORTED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.webp'];

export const ImageUploader = forwardRef<HTMLDivElement, ImageUploaderProps>(
  function ImageUploader({ onImageChange, initialImage, maxSize = 5 }, ref) {
    const [preview, setPreview] = useState<string | undefined>(initialImage);
    const [isDragging, setIsDragging] = useState(false);
    const [error, setError] = useState<string | undefined>();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const validateFile = (file: File): string | null => {
      if (!SUPPORTED_FORMATS.includes(file.type)) {
        return `Unsupported format. Supported formats: ${SUPPORTED_EXTENSIONS.join(', ')}`;
      }

      const fileSizeMB = file.size / (1024 * 1024);
      if (fileSizeMB > maxSize) {
        return `File size exceeds ${maxSize}MB limit`;
      }

      return null;
    };

    const handleFileSelect = (file: File) => {
      const validationError = validateFile(file);
      if (validationError) {
        setError(validationError);
        return;
      }

      setError(undefined);

      const reader = new FileReader();
      reader.onload = (e) => {
        const base64String = e.target?.result as string;
        setPreview(base64String);
        onImageChange?.(base64String);
      };
      reader.readAsDataURL(file);
    };

    const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);

      const files = e.dataTransfer.files;
      if (files.length > 0) {
        handleFileSelect(files[0]);
      }
    };

    const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(true);
    };

    const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragging(false);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.currentTarget.files;
      if (files && files.length > 0) {
        handleFileSelect(files[0]);
      }
    };

    const handleRemove = () => {
      setPreview(undefined);
      setError(undefined);
      onImageChange?.('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };

    return (
      <div ref={ref} className="space-y-4">
        {preview ? (
          <div className="space-y-3">
            <div className="relative w-full aspect-square rounded-lg overflow-hidden bg-surface-2 border border-line/60">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={preview}
                alt="Preview"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 h-10 rounded-lg bg-coffee/20 text-ink hover:bg-coffee/30 text-sm font-medium transition-colors"
              >
                Replace
              </button>
              <button
                type="button"
                onClick={handleRemove}
                className="flex-1 h-10 rounded-lg bg-danger/20 text-danger hover:bg-danger/30 text-sm font-medium transition-colors"
              >
                Remove
              </button>
            </div>
          </div>
        ) : (
          <div
            ref={ref}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            className={cn(
              'relative w-full aspect-square rounded-lg border-2 border-dashed transition-colors cursor-pointer',
              isDragging
                ? 'border-accent bg-accent/5'
                : 'border-line/60 bg-surface-2 hover:bg-surface-2/80'
            )}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept={SUPPORTED_EXTENSIONS.join(',')}
              onChange={handleInputChange}
              className="hidden"
            />
            <div
              onClick={() => fileInputRef.current?.click()}
              className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center"
            >
              <svg
                className="w-12 h-12 text-ink-mute mb-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
              <p className="text-sm font-medium text-ink mb-1">
                Drag & drop your image here
              </p>
              <p className="text-xs text-ink-mute">
                or click to browse files
              </p>
              <p className="text-xs text-ink-mute mt-2">
                Supported: {SUPPORTED_EXTENSIONS.join(', ')} (Max {maxSize}MB)
              </p>
            </div>
          </div>
        )}

        {error && (
          <div className="p-3 rounded-lg bg-danger/10 border border-danger/30 text-danger text-sm">
            {error}
          </div>
        )}
      </div>
    );
  }
);
