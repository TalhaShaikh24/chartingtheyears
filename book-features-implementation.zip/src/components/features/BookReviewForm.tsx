'use client';

import { useState } from 'react';
import { KitLabel, KitInput, KitTextarea } from '@/components/ui/kit/Input';
import { KitButton } from '@/components/ui/kit/Button';
import apiClient from '@/lib/apiClient';

interface BookReviewFormProps {
  bookId: string;
  onReviewSubmitted?: () => void;
}

export function BookReviewForm({ bookId, onReviewSubmitted }: BookReviewFormProps) {
  const [rating, setRating] = useState<number>(5);
  const [userName, setUserName] = useState<string>('');
  const [comment, setComment] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    if (!comment.trim()) {
      setError('Please write a review comment');
      return;
    }

    try {
      setIsSubmitting(true);
      await apiClient.post('/api/reviews', {
        bookId,
        userName: userName || 'Anonymous',
        rating,
        comment,
      });

      setSuccess(true);
      setComment('');
      setUserName('');
      setRating(5);

      setTimeout(() => {
        setSuccess(false);
        onReviewSubmitted?.();
      }, 2000);
    } catch (err) {
      console.error('[v0] Failed to submit review:', err);
      setError('Failed to submit review. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5 rounded-lg border border-line/60 bg-surface-2 p-6">
      <h3 className="text-lg font-semibold text-ink">Write a Review</h3>

      {/* Name */}
      <div>
        <KitLabel htmlFor="user-name">Your Name (Optional)</KitLabel>
        <KitInput
          id="user-name"
          type="text"
          placeholder="Anonymous"
          value={userName}
          onChange={(e) => setUserName(e.target.value)}
        />
      </div>

      {/* Rating */}
      <div>
        <KitLabel htmlFor="rating">Rating</KitLabel>
        <div className="flex gap-3 mt-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              className={`text-3xl transition-transform ${
                star <= rating ? 'text-ink scale-110' : 'text-ink/30 scale-100'
              }`}
            >
              ★
            </button>
          ))}
        </div>
      </div>

      {/* Comment */}
      <div>
        <KitLabel htmlFor="comment">Your Review</KitLabel>
        <KitTextarea
          id="comment"
          placeholder="Share your thoughts about this book..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          maxLength={500}
        />
        <p className="text-xs text-ink-mute mt-1">
          {comment.length}/500 characters
        </p>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-3 rounded-lg bg-danger/10 border border-danger/30 text-danger text-sm">
          {error}
        </div>
      )}

      {/* Success Message */}
      {success && (
        <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/30 text-green-700 text-sm">
          Review submitted successfully!
        </div>
      )}

      {/* Submit Button */}
      <KitButton
        type="submit"
        variant="primary"
        disabled={isSubmitting || !comment.trim()}
        className="w-full"
      >
        {isSubmitting ? 'Submitting...' : 'Submit Review'}
      </KitButton>
    </form>
  );
}
