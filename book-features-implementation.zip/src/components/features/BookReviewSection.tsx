'use client';

import { useEffect, useState } from 'react';
import { Stars } from '@/components/ui/kit/Stars';
import apiClient from '@/lib/apiClient';

interface Review {
  _id: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
}

interface BookReviewSectionProps {
  bookId: string;
  refreshTrigger?: number;
}

export function BookReviewSection({ bookId, refreshTrigger }: BookReviewSectionProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await apiClient.get<{ data: Review[] }>(
          `/api/reviews?bookId=${bookId}`
        );
        setReviews(response.data.data || []);
      } catch (err) {
        console.error('[v0] Failed to fetch reviews:', err);
        setError('Failed to load reviews');
      } finally {
        setLoading(false);
      }
    };

    fetchReviews();
  }, [bookId, refreshTrigger]);

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return 'Unknown date';
    }
  };

  return (
    <div className="space-y-5">
      <h3 className="text-lg font-semibold text-ink">Reviews</h3>

      {error && (
        <div className="p-4 rounded-lg bg-danger/10 border border-danger/30 text-danger text-sm">
          {error}
        </div>
      )}

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="rounded-lg border border-line/60 bg-surface-2 p-4 animate-pulse">
              <div className="h-4 bg-surface-2 rounded w-1/4 mb-2" />
              <div className="h-3 bg-surface-2 rounded w-3/4" />
            </div>
          ))}
        </div>
      ) : reviews.length > 0 ? (
        <div className="space-y-4">
          {reviews.map((review) => (
            <div
              key={review._id}
              className="rounded-lg border border-line/60 bg-surface-2 p-5"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-semibold text-ink">{review.userName}</p>
                  <p className="text-xs text-ink-mute">{formatDate(review.createdAt)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Stars value={review.rating} size={16} />
                  <span className="text-sm font-semibold text-ink">{review.rating}</span>
                </div>
              </div>
              {review.comment && (
                <p className="text-sm text-ink leading-relaxed">{review.comment}</p>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <p className="text-ink-mute">No reviews yet. Be the first to review this book!</p>
        </div>
      )}
    </div>
  );
}
