'use client';

import { Stars } from '@/components/ui/kit/Stars';
import { KitButton } from '@/components/ui/kit/Button';
import { useState } from 'react';

interface ReadingListCardProps {
  _id: string;
  title: string;
  author: string;
  category: string;
  language: string;
  rating: number;
  imageUrl?: string;
  onRemove?: (bookId: string) => void;
}

export function ReadingListCard({
  _id,
  title,
  author,
  category,
  language,
  rating,
  imageUrl,
  onRemove,
}: ReadingListCardProps) {
  const [isRemoving, setIsRemoving] = useState(false);

  const handleRemove = async () => {
    setIsRemoving(true);
    try {
      onRemove?.(_id);
    } finally {
      setIsRemoving(false);
    }
  };

  const placeholderImage = `https://placehold.co/200x280/EADCCB/453C38?text=${encodeURIComponent(title)}`;

  return (
    <div className="rounded-xl bg-surface border border-line/60 overflow-hidden hover:shadow-lg transition-shadow">
      {/* Book Image */}
      <div className="relative w-full aspect-[3/4] bg-surface-2 overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={imageUrl || placeholderImage}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Book Info */}
      <div className="p-4 space-y-3">
        <div>
          <h3 className="font-semibold text-sm leading-tight text-ink line-clamp-2">
            {title}
          </h3>
          <p className="text-xs text-ink-mute mt-1">{author}</p>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5">
          <span className="inline-block px-2 py-1 rounded-full text-xs font-medium bg-ink/10 text-ink">
            {category}
          </span>
          <span className="inline-block px-2 py-1 rounded-full text-xs font-medium bg-accent/10 text-accent">
            {language}
          </span>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-2">
          <Stars value={Math.round(rating)} size={14} />
          <span className="text-xs text-ink-mute">({rating.toFixed(1)})</span>
        </div>

        {/* Remove Button */}
        <KitButton
          variant="danger"
          size="sm"
          onClick={handleRemove}
          disabled={isRemoving}
          className="w-full"
        >
          {isRemoving ? 'Removing...' : 'Remove from list'}
        </KitButton>
      </div>
    </div>
  );
}
