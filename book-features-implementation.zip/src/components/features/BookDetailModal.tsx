'use client';

import { useState } from 'react';
import { Modal } from '@/components/ui/kit/Modal';
import { Stars } from '@/components/ui/kit/Stars';
import { KitButton } from '@/components/ui/kit/Button';
import apiClient from '@/lib/apiClient';

interface BookDetailModalProps {
  open: boolean;
  onClose: () => void;
  onViewFullPage?: () => void;
  book?: {
    _id: string;
    title: string;
    author: string;
    category: string;
    language: string;
    type: string;
    rating: number;
    historicalYear: number;
    publicationYear: number;
    reviewText?: string;
    imageUrl?: string;
  };
}

export function BookDetailModal({ open, onClose, onViewFullPage, book }: BookDetailModalProps) {
  const [isAddingToList, setIsAddingToList] = useState(false);

  const handleAddToReadingList = async () => {
    if (!book) return;

    try {
      setIsAddingToList(true);

      // Generate a consistent user ID for demo
      let userId = localStorage.getItem('demo-user-id');
      if (!userId) {
        userId = `user-${Date.now()}`;
        localStorage.setItem('demo-user-id', userId);
      }

      await apiClient.post('/api/reading-list', {
        userId,
        bookId: book._id,
      });

      // Show success feedback
      alert('Book added to your reading list!');
    } catch (error) {
      console.error('[v0] Failed to add to reading list:', error);
      alert('Failed to add book to reading list');
    } finally {
      setIsAddingToList(false);
    }
  };

  if (!book) return null;

  const placeholderImage = `https://placehold.co/300x420/EADCCB/453C38?text=${encodeURIComponent(book.title)}`;

  return (
    <Modal open={open} onClose={onClose} size="lg">
      <div className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-8">
          {/* Book Cover */}
          <div className="flex flex-col gap-4">
            <div className="relative w-full aspect-[3/4] rounded-xl overflow-hidden bg-surface-2 border border-line/60 flex-shrink-0">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={book.imageUrl || placeholderImage}
                alt={book.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Book Details */}
          <div className="space-y-6">
            {/* Title */}
            <div>
              <h2 className="text-3xl font-bold text-ink mb-2">{book.title}</h2>
              <p className="text-lg text-ink-mute">{book.author}</p>
            </div>

            {/* Badges */}
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold bg-ink text-canvas">
                {book.country || 'Unknown'}
              </span>
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold border border-line bg-transparent text-ink">
                {book.category}
              </span>
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold border border-line bg-transparent text-ink">
                {book.language}
              </span>
              <span className="px-3 py-1.5 rounded-full text-sm font-semibold border border-line bg-transparent text-ink">
                {book.type}
              </span>
            </div>

            {/* Rating */}
            <div className="flex items-center gap-3">
              <Stars value={Math.round(book.rating)} size={20} />
              <span className="text-lg font-semibold text-ink">
                {book.rating.toFixed(1)}/5
              </span>
            </div>

            {/* Info Boxes */}
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border border-line/60 bg-surface-2 p-4">
                <p className="text-xs uppercase font-semibold text-ink-mute tracking-wider mb-1">
                  Historical Range
                </p>
                <p className="text-lg font-bold text-ink">
                  {book.historicalYear}
                </p>
              </div>
              <div className="rounded-lg border border-line/60 bg-surface-2 p-4">
                <p className="text-xs uppercase font-semibold text-ink-mute tracking-wider mb-1">
                  Publication Year
                </p>
                <p className="text-lg font-bold text-ink">
                  {book.publicationYear}
                </p>
              </div>
            </div>

            {/* Description */}
            {book.reviewText && (
              <div className="rounded-lg border border-line/60 bg-surface-2 p-4">
                <p className="text-sm text-ink leading-relaxed">
                  {book.reviewText}
                </p>
              </div>
            )}

            {/* Tags (if any - placeholder) */}
            <div className="flex flex-wrap gap-2">
              <span className="px-2 py-1 rounded-full text-xs font-medium bg-ink/20 text-ink">
                Academic
              </span>
              <span className="px-2 py-1 rounded-full text-xs font-medium bg-ink/20 text-ink">
                Historical
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4 flex-wrap">
              <KitButton
                variant="primary"
                onClick={onViewFullPage}
                className="flex-1 min-w-[150px]"
              >
                Open full review page
              </KitButton>
              <KitButton
                variant="outline"
                onClick={handleAddToReadingList}
                disabled={isAddingToList}
                className="flex-1 min-w-[150px]"
              >
                {isAddingToList ? 'Adding...' : 'Add to Reading List'}
              </KitButton>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}
