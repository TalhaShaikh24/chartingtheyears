'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { BookCard } from './BookCard';
import { BookDetailModal } from './BookDetailModal';

interface BookCardClickableProps {
  _id: string;
  title: string;
  author: string;
  category: string;
  language: string;
  rating: number;
  type: string;
  historicalYear: number;
  publicationYear: number;
  reviewText?: string;
  imageUrl?: string;
  country?: string;
}

export function BookCardClickable({
  _id,
  title,
  author,
  category,
  language,
  rating,
  type,
  historicalYear,
  publicationYear,
  reviewText,
  imageUrl,
  country,
}: BookCardClickableProps) {
  const [modalOpen, setModalOpen] = useState(false);
  const router = useRouter();

  const handleViewFullReview = () => {
    setModalOpen(false);
    router.push(`/user/books/${_id}`);
  };

  return (
    <>
      <div onClick={() => setModalOpen(true)} className="cursor-pointer">
        <BookCard
          title={title}
          author={author}
          category={category}
          language={language}
          rating={rating}
          imageUrl={imageUrl}
        />
      </div>

      <BookDetailModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onViewFullPage={handleViewFullReview}
        book={{
          _id,
          title,
          author,
          category,
          language,
          type,
          rating,
          historicalYear,
          publicationYear,
          reviewText,
          imageUrl,
          country,
        }}
      />
    </>
  );
}
