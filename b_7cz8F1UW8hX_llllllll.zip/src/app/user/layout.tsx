'use client';

import { UserSidebar } from '@/components/layout/UserSidebar';
import { UserTopbar } from '@/components/layout/UserTopbar';
import './user.css';

export default function UserLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="user-layout">
      <UserSidebar />
      <div className="user-layout-main">
        <UserTopbar />
        <main className="user-layout-content">
          {children}
        </main>
      </div>
    </div>
  );
}
