'use client';

import Image from 'next/image';
import { Stars } from '@/components/ui/kit/Stars';
import './BookCard.css';

interface BookCardProps {
  title: string;
  author: string;
  category: string;
  language: string;
  rating: number;
  imageUrl?: string;
}

export function BookCard({
  title,
  author,
  category,
  language,
  rating,
  imageUrl,
}: BookCardProps) {
  return (
    <div className="book-card">
      <div className="book-card-image-wrap">
        <Image
          src={imageUrl || `https://placehold.co/400x533/EADCCB/453C38?text=${encodeURIComponent(title)}`}
          alt={title}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1280px) 25vw, 16vw"
        />
      </div>

      <div className="book-card-body">
        <div>
          <h3 className="book-card-title">{title}</h3>
          <p className="book-card-author">{author}</p>
        </div>

        <div className="book-card-badges">
          <span className="book-card-badge-category">{category}</span>
          <span className="book-card-badge-language">{language}</span>
        </div>

        <div className="book-card-stars">
          <Stars value={Math.round(rating)} size={14} />
        </div>
      </div>
    </div>
  );
}
