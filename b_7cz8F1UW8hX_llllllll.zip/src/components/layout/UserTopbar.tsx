'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import './UserTopbar.css';

const navItems = [
  { label: 'Atlas Dashboard', href: '/user' },
  { label: 'Reading list', href: '/user/reading-list' },
  { label: 'About', href: '/user/about' },
];

export function UserTopbar() {
  const pathname = usePathname();

  return (
    <header className="user-topbar">
      <nav className="user-topbar-nav">
        {navItems.map((item) => {
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`user-topbar-nav-link${active ? ' active' : ''}`}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>

      <button className="user-topbar-lang">EN</button>
    </header>
  );
}
